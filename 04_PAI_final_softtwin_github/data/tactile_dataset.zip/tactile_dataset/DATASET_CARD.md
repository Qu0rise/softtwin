# SoftTwin tactile grasp dataset (synthetic, auto-annotated)

- episodes: 420 (7 object types incl. 2 look-alikes), generated in 4.6 min on 2 CPU cores
- control-rate samples (50 Hz, grasp phase): 121494; each has pressure command / pressure / model bend / 3 finger angles /
  estimated and true grip force / 24 skin taxels (sensor model) / 24 true taxel forces
- images per episode: wrist RGB + depth + segmentation mask (pre-grasp), scene RGB + mask (grasp, lift); 192x144
- labels per episode: object, looks-like, true handling class, visual prior class, max safe force, hidden physics
  (mass, friction, contact time constant, solimp), random target force, outcome (success 55%, crushed 24%, slipped 21%),
  bounding boxes, probe and vision feature vectors
- files: `index.jsonl` / `index.parquet` (one row per episode), `episodes/ep_XXXXX.npz`
- all annotations come from the simulator; skin values pass through `tactile.FabricSkin` (crosstalk, gain error, lag, noise,
  dead zone, saturation, 12-bit ADC). Numbers are assumptions for a textile piezoresistive skin, not a calibrated device.
- skipped episodes (renderer crash): 0
